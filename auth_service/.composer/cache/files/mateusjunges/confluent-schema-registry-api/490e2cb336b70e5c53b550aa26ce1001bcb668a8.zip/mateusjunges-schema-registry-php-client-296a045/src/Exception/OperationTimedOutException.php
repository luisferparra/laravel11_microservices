<?php

namespace FlixTech\SchemaRegistryApi\Exception;

class OperationTimedOutException extends AbstractSchemaRegistryException
{
    public const ERROR_CODE = 50002;
}
