<?php

declare(strict_types=1);

namespace Widmogrod\Monad\IO;

class IOError extends \Exception
{
}
