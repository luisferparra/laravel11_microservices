---
title: v2.0
slogan: Use Kafka Producers and Consumers in your laravel app with ease!
githubUrl: https://github.com/mateusjunges/laravel-kafka
branch: master
---
