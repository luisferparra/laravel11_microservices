<?php declare(strict_types=1);

namespace Junges\Kafka\Exceptions;

use Exception;

abstract class LaravelKafkaException extends Exception
{
}
