---
title: Changelog
weight: 5
---

All notable changes to laravel kafka are documented on [GitHub](https://github.com/mateusjunges/laravel-kafka/blob/v2.x/CHANGELOG.md).

```+parse
<x-newsletter />
```